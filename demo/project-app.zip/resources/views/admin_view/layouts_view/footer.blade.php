<footer class="footer container-fluid pl-30 pr-30">
    <div class="row">
        <div class="col-sm-12">
            <p>2023 &copy; Công Ty TNHH Tư Vấn S&D Laws</p>
        </div>
    </div>
</footer>

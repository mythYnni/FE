<!-- :: Search Box -->
<div class="search-box">
    <form>
        <input type="search" placeholder="Search Here..">
        <button type="submit"><i class="fas fa-search"></i></button>
    </form>
</div>

<div class="modal" id="myModal_price">
     <div class="modal-dialog modal-xl">
          <div class="modal-content">

               <!-- Modal Header -->
               <div class="modal-header">
                    <h4 class="modal-title">Chi Tiết Bảng Giá Dịch Vụ</h4>
               </div>

               <!-- Modal body -->
               <div class="modal-body">
                    <div class="table-responsive">
                          <table class="table table-bordered">
                               <thead class="table-warning">
                                    <tr>
                                         <th class="col-lg-2 col-md-2 col-sm-2">Tên Gói</th>
                                         <th class="col-lg-3 col-sm-3 col-sm-3">Giá</th>
                                         <th class="col-lg-2 col-md-2 col-sm-2">Thời Gian</th>
                                         <th class="col-lg-5 col-md-5 col-sm-5">Chi Tiết</th>
                                    </tr>
                               </thead>
                               <tbody id="modal-body-price">

                               </tbody>
                          </table>
                    </div>
               </div>
          </div>
     </div>
</div>

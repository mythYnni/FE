<div class="modal" id="myModal_blog">
     <div class="modal-dialog modal-xl">
          <div class="modal-content">

               <!-- Modal Header -->
               <div class="modal-header">
                    <h4 class="modal-title">Chi Tiết Bài viết</h4>
               </div>

               <!-- Modal body -->
               <div class="modal-body">
                   <div class="container">
                        <div class="row" id="modal-body">
                             <div class="col-md-9">
                             </div>
                             <div class="col-md-3">

                             </div>
                        </div>
                   </div>
               </div>

          </div>
     </div>
</div>
